package com.sprytech.demo.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.sprytech.demo.R

class DepositActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deposit)
    }
}