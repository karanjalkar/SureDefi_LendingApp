const router = require('express').Router();

const mysqlConnection = require("../mysql/connection")
var async = require('async');
const mysql = require("mysql");
const HederaClient = require('../routes/avalanche/mnemonic');

router.post('/createAccount', async (req, res) => {
  console.log("in account create")
  var mobile = req.query.mobile
  var username = req.query.username
  var email = req.query.email
  var password = req.query.password

  var output = {}

  let errors = false;
  if (mobile.length === 0 || username.length === 0 || email.length === 0 || email.password === 0) {
    errors = true;
    output["status"] = false
    res.send(output)
    return

  }
  
  if (!errors) {

    var form_data = {
      name: username,
      email: email,
      mobile: mobile,
      publicKey: "",
      privateKey: "",
      accountId: "",
      password: password
    }

    // insert query
    mysqlConnection.query('INSERT INTO passport_users SET ?', form_data, function (err, result) {
      //if(err) throw err
      console.log("error", err)
      if (err) {

        output["status"] = false
        res.send(output)
      } else {

        output["status"] = true
        output["id"] = result.insertId
        output["name"] = username
        output["email"] = email
        output["mobile"] = mobile
        output['Avalanche'] = ""
        console
        res.send(output)


      }
    })
  }

});


router.post("/getAccount", async (req, res) => {

  // var mobile = req.query.mobile
  var email = req.query.email
  var password = req.query.password


  var jsonArr = []
  const promises = []

  var bigOutput = {}
  var output = [];
  var sql = ""
  if (email && password) {
    sql = mysql.format("select * from passport_users where email=? && password=?", [email, password])
  } else {

  }

  mysqlConnection.query(sql, function (error, results, filelds) {
    if (error) {
      console.log(error)
      var json = {}
      json['status'] = false
      res.send(json)
    } else {

      if (results.length > 0) {
        var json = {}
        json['status'] = true
        json['name'] = results[0].name
        json['id'] = results[0].id
        json['email'] = results[0].email
        json['mobile'] = results[0].mobile
        json['password'] = results[0].password
        json['hederaAccount'] = { "accountId": results[0].accountId, "publicKey": results[0].publicKey, "privateKey": results[0].privateKey }

        res.send(json)
      } else {
        var json = {}
        json['status'] = false
        res.send(json)
      }


    }
  });


});



module.exports = router;