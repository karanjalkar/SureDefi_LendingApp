package com.mindorks.retrofit.coroutines.ui.base

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.metamask.repository.RemoteRepository
import com.example.play2win.LocalAuthRepository
import com.mindorks.retrofit.coroutines.data.api.ApiService
import com.sprytech.demo.AuthViewModel
import com.sprytech.demo.home.HomeViewModel
import com.sprytech.demo.registration.RegistrationViewModel
import com.sprytech.vaccinepassport.ui.auth.login.*

class ViewModelFactory(private val apiService: ApiService,private val apiService2: ApiService, private val context: Context) : ViewModelProvider.Factory {

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {

        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            return LoginViewModel(RemoteRepository(apiService),LocalAuthRepository(context)) as T
        }
        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            return AuthViewModel(
                RemoteRepository(apiService),
                LocalAuthRepository(context)
            ) as T
        }

        if (modelClass.isAssignableFrom(RegistrationViewModel::class.java)) {
            return RegistrationViewModel(
                RemoteRepository(apiService),
                LocalAuthRepository(context)
            ) as T
        }

        if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
            return HomeViewModel(RemoteRepository(apiService), LocalAuthRepository(context)) as T
        }

        if (modelClass.isAssignableFrom(HomeFragViewModel::class.java)) {
            return HomeFragViewModel(RemoteRepository(apiService), RemoteRepository(apiService2), LocalAuthRepository(context)) as T
        }

        if (modelClass.isAssignableFrom(AccountInfoViewModel::class.java)) {
            return AccountInfoViewModel(RemoteRepository(apiService), RemoteRepository(apiService2), LocalAuthRepository(context)) as T
        }

        if (modelClass.isAssignableFrom(DepositViewModel::class.java)) {
            return DepositViewModel(RemoteRepository(apiService), RemoteRepository(apiService2), LocalAuthRepository(context)) as T
        }

        if (modelClass.isAssignableFrom(WithdrawViewModel::class.java)) {
            return WithdrawViewModel(RemoteRepository(apiService), RemoteRepository(apiService2), LocalAuthRepository(context)) as T
        }

        if (modelClass.isAssignableFrom(DepositBalanceViewModel::class.java)) {
            return DepositBalanceViewModel(RemoteRepository(apiService), RemoteRepository(apiService2), LocalAuthRepository(context)) as T
        }

        if (modelClass.isAssignableFrom(EthAccountViewModel::class.java)) {
            return EthAccountViewModel(RemoteRepository(apiService), RemoteRepository(apiService2), LocalAuthRepository(context)) as T
        }

        /*if (modelClass.isAssignableFrom(PatientRegisterViewModel::class.java)) {
            return PatientRegisterViewModel(RemoteRepository(apiService), LocalAuthRepository(context)) as T
        }

        if (modelClass.isAssignableFrom(PatientDetailsViewModel::class.java)) {
            return PatientDetailsViewModel(RemoteRepository(apiService), LocalAuthRepository(context)) as T
        }*/
        /*if (modelClass.isAssignableFrom(LoadAccountViewModel::class.java)) {
            return LoadAccountViewModel(MainRepository(apiHelper),LocalAuthRepository(context)) as T
        }
        if (modelClass.isAssignableFrom(CreateAccountViewModel::class.java)) {
            return CreateAccountViewModel(MainRepository(apiHelper),LocalAuthRepository(context)) as T
        }
        if (modelClass.isAssignableFrom(TestHtsViewModel::class.java)) {
            return TestHtsViewModel(MainRepository(apiHelper),LocalAuthRepository(context)) as T
        }*/
        throw IllegalArgumentException("Unknown class name")
    }

}

