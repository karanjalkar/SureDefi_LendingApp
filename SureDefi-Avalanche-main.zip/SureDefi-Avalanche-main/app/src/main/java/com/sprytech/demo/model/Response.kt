package com.sprytech.vaccinepassport.model

data class Response(
        val status : Boolean,
        val bal : String,
        val daiBal : String,
        val tokenId : String,
        val hbarBalance : String,
        val balance : String,
        val depositedAmount : String,
        val seed_phrase : String,
        val account_address : String,
        val address : String,
        val private_key : String,
        val privateKey : String
)