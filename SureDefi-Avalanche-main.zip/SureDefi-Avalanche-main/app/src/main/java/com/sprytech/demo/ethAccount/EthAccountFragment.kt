package com.sprytech.demo.ethAccount

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.navGraphViewModels
import com.developer.kalert.KAlertDialog
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentDepositBinding
import com.sprytech.demo.databinding.FragmentEthAccountBinding
import com.sprytech.demo.home.HomeViewModel
import com.sprytech.vaccinepassport.model.TimeD
import com.sprytech.vaccinepassport.ui.auth.login.DepositViewModel
import com.sprytech.vaccinepassport.ui.auth.login.EthAccountViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class EthAccountFragment : BaseFragment<FragmentEthAccountBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_eth_account

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    val viewModel: EthAccountViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, it) }).get(EthAccountViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel


        binding.llAccountDetails.visibility = View.GONE

        binding.btnCreate.setOnClickListener {
            convertToHDai()
        }
    }

    fun convertToHDai() {

        viewModel.createEth().observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()

                        val address = navGraphScopedViewModel.getCurrentUser()?.hederaAccount!!.accountId
                        resource.data?.let { depDai ->


                            if(depDai.status){


                                binding.llAccountDetails.visibility = View.VISIBLE
                                binding.tvSeedPhrase.text = depDai.seed_phrase
                                binding.tvAccountId.text = depDai.account_address
                                binding.tvPrivateKey.text = depDai.private_key

                            }else{

                                KAlertDialog(activity)
                                        .setTitleText("Transfer Failed!")
                                        .setContentText("You don't have sufficient hDAI in your account.")
                                        .show()
                            }



                         //   Log.d("DEBUG", depDai.toString())


                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })



    }


    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            EthAccountFragment()
    }
}