package com.sprytech.vaccinepassport.model

data class SendBody(

        val jsonrpc : String,
        val id : Int,
        val method : String,
        val params : Params
)