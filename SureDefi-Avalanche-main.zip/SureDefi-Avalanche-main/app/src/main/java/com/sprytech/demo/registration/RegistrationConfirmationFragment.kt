package com.sprytech.demo.registration

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.navGraphViewModels
import com.sprytech.demo.AuthViewModel
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentRegistrationConfirmation2Binding
import com.sprytech.demo.home.HomeActivity
import com.sprytech.demo.home.HomeActivity2
import com.tapadoo.alerter.Alerter


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [RegistrationConfirmationFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class RegistrationConfirmationFragment : Fragment() {

    private val navGraphScopedViewModel: AuthViewModel by navGraphViewModels(R.id.auth_navigation)
    lateinit var binding: FragmentRegistrationConfirmation2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_registration_confirmation, container, false)

         binding = DataBindingUtil.inflate(
                inflater,
                R.layout.fragment_registration_confirmation_2, container, false)

        showData()


        binding.btnCopySecretPhrase.setOnClickListener {
            val profile = navGraphScopedViewModel.getCurrentUser2()
            val clipboard: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            val clip = ClipData.newPlainText("asd", "Seed Phrase: " + profile?.mnemonicePhrase )
            clipboard?.setPrimaryClip(clip)

            Alerter.create(activity)
                .setTitle("Alert")
                .setText("Information copied successfully! Store it in safe.")
                .setIconColorFilter(0)
                .setBackgroundColorRes(R.color.green1) // or setBackgroundColorInt(Color.CYAN)
                .show()
          Toast.makeText(activity, "Copied to clipboard successfully", Toast.LENGTH_LONG).show()
        }


        binding.btnCopyEthAddress.setOnClickListener {
            val profile = navGraphScopedViewModel.getCurrentUser2()
            val clipboard: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            val clip = ClipData.newPlainText("asd", "Seed Phrase: " + profile?.xChainAddress )
            clipboard?.setPrimaryClip(clip)

            Alerter.create(activity)
                    .setTitle("Alert")
                    .setText("Information copied successfully! Store it in safe.")
                    .setIconColorFilter(0)
                    .setBackgroundColorRes(R.color.green1) // or setBackgroundColorInt(Color.CYAN)
                    .show()
            Toast.makeText(activity, "Copied to clipboard successfully", Toast.LENGTH_LONG).show()
        }

        binding.btnContinue.setOnClickListener {
            startActivity(Intent(activity, HomeActivity2::class.java))
            activity?.finish()
        }


        return binding.root
    }


    private fun showData(){

        val profile = navGraphScopedViewModel.getCurrentUser2()

       // binding.tvAccountId.setText(profile?.hederaAccount?.accountId)
        binding.edSecredPhrase.setHint( profile?.mnemonicePhrase)
        binding.edXChainAddress.setHint( profile?.xChainAddress)


    }
    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment RegistrationConfirmationFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            RegistrationConfirmationFragment()
    }
}