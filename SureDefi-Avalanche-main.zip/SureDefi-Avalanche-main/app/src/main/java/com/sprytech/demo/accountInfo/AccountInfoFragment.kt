package com.sprytech.fineart.ui.home.accountInfo

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentRegistrationConfirmationBinding
import com.sprytech.demo.home.HomeViewModel
import com.sprytech.vaccinepassport.ui.auth.login.AccountInfoViewModel
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment
import com.tapadoo.alerter.Alerter

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [RegistrationConfirmationFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class AccountInfoFragment : BaseFragment<FragmentRegistrationConfirmationBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_registration_confirmation
    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    val viewModel: AccountInfoViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(
                RetrofitBuilder.apiService,
                RetrofitBuilder.apiService2, it) }).get(AccountInfoViewModel::class.java)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }




    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvTitle.setText("Account Info")
        binding.btnNext.setOnClickListener {
           // findNavController().navigate(AccountInfoFragmentDirections.actionAccountInfoFragmentToTokenStatusFragment())
        }


        showData()

        gas()

        binding.btnCopy.setOnClickListener {
            val profile = navGraphScopedViewModel.getCurrentUser()
            val clipboard: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            val clip = ClipData.newPlainText("asd", "Account Id: " + profile?.hederaAccount?.accountId + "/n Private Key: " + profile?.hederaAccount?.privateKey )
            clipboard?.setPrimaryClip(clip)

            Alerter.create(activity)
                .setTitle("Alert")
                .setText("Information copied successfully! Store it in safe.")
                .setIconColorFilter(0)
                .setBackgroundColorRes(R.color.green1) // or setBackgroundColorInt(Color.CYAN)
                .show()
            Toast.makeText(activity, "Copied to clipboard successfully", Toast.LENGTH_LONG).show()
        }

        binding.btnNext.setOnClickListener {
            //startActivity(Intent(activity, HomeActivity::class.java))
           // activity?.finish()
        }
    }

    private fun showData(){

        val profile = navGraphScopedViewModel.getCurrentUser()

        binding.tvAccountId.setText(profile?.hederaAccount?.accountId)
        binding.tvPrivateKey.setText(profile?.hederaAccount?.privateKey)


    }



    fun gas() {



        val address = navGraphScopedViewModel.getCurrentUser()?.hederaAccount!!.accountId

        viewModel.bal(address).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->
                            binding.llContainer.visibility = View.VISIBLE

                            binding.tvDaiBalance.text = depDai.balance

                            Log.d("DEBUG", depDai.toString())

                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress("Loading...")
                    }
                }
            }
        })



    }

}