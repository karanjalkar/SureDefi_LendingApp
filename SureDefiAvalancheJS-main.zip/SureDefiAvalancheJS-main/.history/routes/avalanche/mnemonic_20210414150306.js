
async function generateMnemonic() {

}