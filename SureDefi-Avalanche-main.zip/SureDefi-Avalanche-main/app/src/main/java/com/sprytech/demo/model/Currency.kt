package com.sprytech.vaccinepassport.model

data class Currency(
        val status : Boolean,
        val name: String,
        val value: String,
        var balance: String

)