package com.example.metamask.repository

import com.mindorks.retrofit.coroutines.data.api.ApiService
import com.sprytech.vaccinepassport.model.*
import com.sprytech.vaccinepassport.repository.remote.IremoteRepository

class RemoteRepository(private val apiService: ApiService) : IremoteRepository {


    override suspend fun login(email: String, password : String) = apiService.getAccount(email,  password)
    override suspend fun signUp(name :String, email: String, mobile : String, password : String) = apiService.createAccount(name, email, mobile, password)
    override suspend fun signUpAva(name :String, email: String, mobile : String, password : String) = apiService.createAccountAva(name, email, mobile, password)
    override suspend fun patientRegistration(
        name: String,
        address: String,
        dob: String,
        blood_group: String,
        vaccine_name: String,
        vaccine_type: String,
        company: String,
        date_of_vaccine: String,
        dose_no: String,
        id: String
    ) = apiService.patientRegistration(name, address, dob, blood_group, vaccine_name,  vaccine_type, company, date_of_vaccine,
    dose_no, id)

    override suspend fun getPatientDetails(tokenId: String) = apiService.getPatientDetails(tokenId)

    override suspend fun getDepDai(gas: String) = apiService.depDai(gas)
    override suspend fun getGas() = apiService.gas()
    override suspend fun getBalance(address : String) = apiService.bal(address)

    override suspend fun convertToHDai(
        rid: String,
        amount: String,
        pk: String,
        hbarFee: String,
        token_id: String,
        token_private_key: String,
        token_public_key: String
    ) = apiService.convertToHDai(rid, amount, pk, hbarFee,token_id, token_private_key, token_public_key)

    override suspend fun createEthAccount() = apiService.createEthAccount()
    override suspend fun getEthAccount(seed: String) = apiService.getEthAccount(seed)
    override suspend fun sendAva(body: SendBody) = apiService.sendAva(body)


    override suspend fun deposit(
        rid: String,
        amount: String,
        pk: String,
        hbarFee: String,
        token_id: String,
        token_private_key: String,
        token_public_key: String
    ) = apiService.deposit(rid, amount, pk, hbarFee,token_id, token_private_key, token_public_key)

    override suspend fun withdraw(
        rid: String,
        amount: String,
        pk: String,
        hbarFee: String,
        token_id: String,
        token_private_key: String,
        token_public_key: String
    ) = apiService.withdraw(rid, amount, pk, hbarFee,token_id, token_private_key, token_public_key)

    override suspend fun depositedBalance(
        rid: String

    ) = apiService.depositedBalance(rid)

}