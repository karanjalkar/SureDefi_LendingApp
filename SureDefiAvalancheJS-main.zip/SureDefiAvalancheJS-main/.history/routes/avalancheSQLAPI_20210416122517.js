const router = require('express').Router();

const mysqlConnection = require("../mysql/connection")
var async = require('async');
const mysql = require("mysql");
const menmonicService = require('../routes/avalanche/mnemonic');
// const addGenService = require('../routes/avalanche/address_gen');

const HDKey = require('hdkey');
const bip39 = require('bip39');
const Buffer = require('buffer/').Buffer;
// const AVM = require('avalanche/dist/apis/avm');
const Utils = require('avalanche/dist/utils')
const AVAX_ACCOUNT_PATH = `m/44'/9000'/0'`;

//
const { Avalanche, BinTools,
  BN } = require("avalanche");
const avalanche = require("avalanche");

let bintools = BinTools.getInstance();

// const { KeyChain } = require("./keychain")
// import Avalanche, {
//   AVM,
//   AVMKeyChain,
//   BinTools,
//   getPreferredHRP,
//   PlatformVMKeyChain
// } from "avalanche" 

router.post('/createAccount', async (req, res) => {
  console.log("in account create")
  var mobile = req.query.mobile
  var username = req.query.username
  var email = req.query.email
  var password = req.query.password

  var output = {}

  let errors = false;
  if (mobile.length === 0 || username.length === 0 || email.length === 0 || email.password === 0) {
    errors = true;
    output["status"] = false
    res.send(output)
    return

  }

  const mnemonicePhrase = await menmonicService.generateMnemonic();
  console.log({ mnemonicePhrase });
  const xChainAddress = await generateAddresses(mnemonicePhrase, 1);
  console.log({ xChainAddress });

  if (!errors) {

    var form_data = {
      name: username,
      email: email,
      mobile: mobile,
      publicKey: "",
      privateKey: "",
      accountId: mnemonicePhrase,
      password: password
    }

    // insert query
    // mysqlConnection.query('INSERT INTO passport_users SET ?', form_data, function (err, result) {
    //   //if(err) throw err
    //   console.log("error", err)
    //   if (err) {

    //     output["status"] = false
    //     res.send(output)
    //   } else {

    //     output["status"] = true
    //     output["id"] = result.insertId
    //     output["name"] = username
    //     output["email"] = email
    //     output["mobile"] = mobile
    //     output['mnemonicePhrase'] = mnemonicePhrase
    //     console
    //     res.send(output)


    //   }
    // })
  }

});


router.post("/getAccount", async (req, res) => {

  // var mobile = req.query.mobile
  var email = req.query.email
  var password = req.query.password


  var jsonArr = []
  const promises = []

  var bigOutput = {}
  var output = [];
  var sql = ""
  if (email && password) {
    sql = mysql.format("select * from passport_users where email=? && password=?", [email, password])
  } else {

  }

  mysqlConnection.query(sql, function (error, results, filelds) {
    if (error) {
      console.log(error)
      var json = {}
      json['status'] = false
      res.send(json)
    } else {

      if (results.length > 0) {
        var json = {}
        json['status'] = true
        json['name'] = results[0].name
        json['id'] = results[0].id
        json['email'] = results[0].email
        json['mobile'] = results[0].mobile
        json['password'] = results[0].password
        json['mnemonicePhrase'] = results[0].accountId
        // json['hederaAccount'] = { "accountId": results[0].accountId, "publicKey": results[0].publicKey, "privateKey": results[0].privateKey }

        res.send(json)
      } else {
        var json = {}
        json['status'] = false
        res.send(json)
      }


    }
  });


});

async function generateAddresses(mnemonicIn, num) {
  let hrp = Utils.getPreferredHRP(1);
  let keychain = await myKeychain();
  // mnemonicIn = 'carbon brass decorate avoid deny chaos rebuild slide write pupil pupil year account what cinnamon eight make life involve exotic start midnight sniff skinclear'
  let mnemonic = mnemonicIn.trim();

  if (bip39.validateMnemonic(mnemonic) == false) {
      console.log("\n\n[ERROR] Your mnemonic is invalid. Did you generate it manually? Use a proper BIP-39 mnemonic generation tool, such as the one in this repository.");
      process.exit();
  }

  const seed = bip39.mnemonicToSeedSync(mnemonic)
  const hdkey = HDKey.fromMasterSeed(seed)

  let keys = [];
  for (let i = 0; i < num; i++) {
    let derivationPath = `${AVAX_ACCOUNT_PATH}/0/${i}`;
    let key = hdkey.derive(derivationPath)
    keys.push(key);
  }

  let addrs = keys.map((key) => {
    let privateKeyHEX = key.privateKey.toString('hex');
    let privateKeyBuffer = new Buffer(privateKeyHEX, 'hex');
    let keypair = keychain.importKey(privateKeyBuffer);
    // console.log(privateKeyHEX);
    // console.log(keypair.getPublicKey().toString('hex'));
    return keypair.getAddressString();
  });

  return addrs;
}


 async function myKeychain() {
  let myNetworkID = 5; //default is 3, we want to override that for our local network
  let myBlockchainID = "2JVSBoinj9C2J33VntvzYtVJNZdN2NKiwwKjcumHUWEb5DbBrm"; // The X-Chain blockchainID on this network
  let ava = new avalanche.Avalanche("54.154.163.205", 9650, "http", myNetworkID, myBlockchainID);
  let xchain = ava.XChain(); //returns a reference to the X-Chain used by AvalancheJS

  let myKeychain = xchain.keyChain();
  return myKeychain;
}

module.exports = router;