package com.sprytech.demo.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.sprytech.demo.R
import kotlinx.android.synthetic.main.activity_home2.*

class HomeActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home2)

        openFragment2("home")
        btn_home.setOnClickListener{
            openFragment2("home")
        }

        btn_investment.setOnClickListener {
            Log.d("DEBUG", "its here")
            openFragment2("investment")
        }

        btn_activity.setOnClickListener {
            openFragment2("activity")
        }


    }


    private fun openFragment2( fragmentTag : String) {
        tv_home.setTextColor(getColor(R.color.black))
        tv_investment.setTextColor(getColor(R.color.black))
        tv_activity.setTextColor(getColor(R.color.black))


        val manager = supportFragmentManager
        val transaction = manager.beginTransaction().apply {
            val cachedFragment = manager.findFragmentByTag(fragmentTag)
            val currentFragment = manager.findFragmentById(R.id.container)
            if (null != currentFragment) detach(currentFragment)
            if (null == cachedFragment) {

                if(fragmentTag.equals("home")){
                    tv_home.setTextColor(getColor(R.color.color4))
                    val songsFragment = HomeFragment2.newInstance("1","2")
                    add(R.id.container, songsFragment, fragmentTag)
                    //songsFragment.onResume()

                }else if(fragmentTag.equals("investment")){
                    tv_investment.setTextColor(getColor(R.color.color4))
                   val songsFragment = InvestMentFragment.newInstance("1","2")
                    add(R.id.container, songsFragment, fragmentTag)

                }else if(fragmentTag.equals("activity")){
                    tv_activity.setTextColor(getColor(R.color.color4))
                    val songsFragment = ActivityFragment.newInstance("1","2")
                    add(R.id.container, songsFragment, fragmentTag)

                }else if(fragmentTag.equals("activity")){

                   // val songsFragment = ActivityFragment.newInstance("1","2")
                   // add(R.id.container, songsFragment, fragmentTag)

                }else if(fragmentTag.equals("setting")){

                   // val songsFragment = SettingFragment.newInstance("1","2")
                   // add(R.id.container, songsFragment, fragmentTag)

                }


            } else {
                attach(cachedFragment)
              //  cachedFragment.onResume()
            }
        } .commitAllowingStateLoss()





    }
}