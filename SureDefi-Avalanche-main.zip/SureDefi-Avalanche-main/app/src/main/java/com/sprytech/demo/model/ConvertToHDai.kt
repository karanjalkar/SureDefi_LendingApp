package com.sprytech.vaccinepassport.model

data class ConvertToHDai(

        val status : String
)