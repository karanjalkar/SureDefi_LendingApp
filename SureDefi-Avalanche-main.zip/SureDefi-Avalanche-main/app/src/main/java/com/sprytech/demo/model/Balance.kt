package com.sprytech.vaccinepassport.model

data class Balance(

        val bal : String,
        val tokenId : String,
        val hbarBalance : String,
        val hDAIBalance : String,
        val sDAIBalance : String,
        val balance : String
)