package com.mindorks.retrofit.coroutines.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}