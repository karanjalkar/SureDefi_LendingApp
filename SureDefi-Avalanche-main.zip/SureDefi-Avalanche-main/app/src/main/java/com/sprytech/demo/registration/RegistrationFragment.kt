package com.sprytech.demo.registration

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.AuthViewModel
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentRegistration2Binding
import com.sprytech.demo.databinding.FragmentRegistration3Binding
import com.sprytech.vaccinepassport.ui.base.BaseFragment
import kotlinx.android.synthetic.main.fragment_registration_2.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [RegistrationFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class RegistrationFragment : BaseFragment<FragmentRegistration3Binding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_registration_3

    private val navGraphScopedViewModel: AuthViewModel by navGraphViewModels(R.id.auth_navigation)
    //val loadAccountViewModel: LoadAccountViewModel by lazy { ViewModelProviders.of(this).get(LoadAccountViewModel::class.java) }
    val viewModel: RegistrationViewModel by lazy {
        ViewModelProviders.of(this,
                activity?.let { ViewModelFactory(RetrofitBuilder.apiService4,RetrofitBuilder.apiService4, it) }).get(
            RegistrationViewModel::class.java)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel

        binding.btnSignup.setOnClickListener {
            // findNavController().navigate(R.id.enterPhoneNumberFragment)
            signUp()
        }

    }



    private fun signUp(){

        viewModel.signUp().observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { account ->
                            if(account.status){
                                RegistrationFragment.seed = account.mnemonicePhrase
                                Log.d("DEBUG", account.mnemonicePhrase)
                                navGraphScopedViewModel.saveProfile2( account)
                                findNavController().navigate(R.id.registrationConfirmationFragment)

                            }else{
                                Toast.makeText(activity, "Invalid credentials!", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })
    }

    companion object {

        var seed : String = "asd"

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            RegistrationFragment()
    }
}