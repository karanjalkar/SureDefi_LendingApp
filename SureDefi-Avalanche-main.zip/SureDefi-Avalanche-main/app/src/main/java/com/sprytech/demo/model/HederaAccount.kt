package com.sprytech.vaccinepassport.model

import java.security.PrivateKey
import java.security.PublicKey

data class HederaAccount(val accountId : String, val publicKey: String, val privateKey: String)