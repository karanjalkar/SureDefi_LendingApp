package com.sprytech.demo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.sprytech.demo.home.HomeActivity
import com.sprytech.demo.home.HomeActivity2

class MainActivity : AppCompatActivity() {

    private val navController by lazy { findNavController(R.id.myNavHostFragment) }
    private var viewModel: AuthViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupViewModel()

        if(viewModel!!.isLoggedIn()){
          // startActivity(Intent(this, HomeActivity2::class.java))
           //finish()
        }


    }

    private fun setupViewModel() {
        try {
            val viewModelProvider = ViewModelProvider(
                navController.getViewModelStoreOwner(R.id.auth_navigation),
                ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, this)
            )
            viewModel = viewModelProvider.get(AuthViewModel::class.java)

        } catch (e: IllegalArgumentException) {
            e.printStackTrace()
        }

    }
}