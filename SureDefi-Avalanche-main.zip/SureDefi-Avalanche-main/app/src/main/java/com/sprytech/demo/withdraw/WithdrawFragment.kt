package com.sprytech.demo.withdraw

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.navGraphViewModels
import com.developer.kalert.KAlertDialog
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentDepositBinding
import com.sprytech.demo.databinding.FragmentDepositedBalanceBinding
import com.sprytech.demo.databinding.FragmentHomeBinding
import com.sprytech.demo.databinding.FragmentWithdrawBinding
import com.sprytech.demo.home.HomeViewModel
import com.sprytech.vaccinepassport.ui.auth.login.DepositBalanceViewModel
import com.sprytech.vaccinepassport.ui.auth.login.DepositViewModel
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.auth.login.WithdrawViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class WithdrawFragment : BaseFragment<FragmentWithdrawBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_withdraw

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    val viewModel: WithdrawViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, it) }).get(WithdrawViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel


        //gas()

       var deposit = viewModel.getDepositedAmount()

        val startTime = viewModel.getTime()

        val currentTime = System.currentTimeMillis()

        val diff: Long = currentTime - startTime.time
        val seconds = diff / 1000
       var interest = seconds / 5

        val value = deposit + interest
       if(deposit != 0){
           viewModel.setBalance(value.toString())
       }else{
           viewModel.setBalance("0")
       }



        binding.btnWithdraw.setOnClickListener {
            convertToHDai()
        }
    }

    fun gas() {


        val profile = navGraphScopedViewModel.getCurrentUser()

        viewModel.depositedBalance(profile?.hederaAccount!!.accountId).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->

                            viewModel.setBalance(depDai.depositedAmount)


                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress("Transfering...")
                    }
                }
            }
        })



    }

    fun convertToHDai() {


        val profile = navGraphScopedViewModel.getCurrentUser()

        val tokenId = "0.0.387538"
        val tprk  = "302e020100300506032b657004220420abe49797c00c3e8023856f6d3d10a97610e98147f943d67c13ec36f5b9fe78fb"
        val tpvk = "302a300506032b657003210024ab3e9183a014bb6bbe4fd7e6c2e814e9f4bee9d8f93d45b3a984bdd2f896d8"

        viewModel.withdraw(profile?.hederaAccount!!.accountId, "100",profile.hederaAccount.privateKey,
            "0", tokenId, tprk, tpvk).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        val value = binding.edEmail.text.toString()
                        val address = navGraphScopedViewModel.getCurrentUser()?.hederaAccount!!.accountId
                        resource.data?.let { depDai ->



                            KAlertDialog(activity)
                                .setTitleText("Transfer Success!")
                                .setContentText(value + " DAI has been withdrawn successfuly")
                                .show()


                            viewModel.setBalance("0")

                            viewModel.saveDepositAmount()

                            Log.d("DEBUG", depDai.toString())


                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })



    }


    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            WithdrawFragment()
    }
}