package com.mindorks.retrofit.coroutines.data.api



import com.sprytech.vaccinepassport.model.*
import retrofit2.http.*
import java.security.PrivateKey

interface ApiService {


    @POST("hederaSQLAPI/getAccount")
    suspend fun getAccount(@Query("email") email: String, @Query("password") password: String): UserProfile


    @POST("hederaSQLAPI/createAccount")
    suspend fun createAccount(@Query("username") username: String, @Query("email") email: String, @Query("mobile") mobile: String, @Query("password") password: String): UserProfile


    @POST("avalancheSQLAPI/createAccount")
    suspend fun createAccountAva(@Query("username") username: String, @Query("email") email: String, @Query("mobile") mobile: String, @Query("password") password: String): UserProfile2


    @POST("vaccinePassportAPI/patientRegistration")
    suspend fun patientRegistration(
        @Query("name") name: String,
        @Query("address") address: String,
        @Query("dob") dob: String,
        @Query("blood_group") blood_group: String,
        @Query("vaccine_name") vaccine_name: String,
        @Query("vaccine_type") vaccine_type: String,
        @Query("company") company: String,
        @Query("date_of_vaccine") date_of_vaccine: String,
        @Query("dose_no") dose_no: String,
        @Query("id") id: String


    ): Patient


    @POST("vaccinePassportAPI/getTokenInfo")
    suspend fun getPatientDetails(
        @Query("tokenId") tokenId: String

    ): Patient


    @POST("eth/depDai")
    suspend fun depDai(
        @Query("gasPrice") gasPrice: String

    ): DepDai

    @GET("eth/gasPrice")
    suspend fun gas(


    ): Gas

    @POST("htsTokenAPI/account-info")
    suspend fun bal(
        @Query("accounId") accounId : String

    ): Balance


    @POST("lendingAPI/currentDepositedBalance")
    suspend fun depositedBalance(
        @Query("sid") accounId : String

    ): Response


    @POST("lendingAPI/deposit-amount")
    suspend fun deposit(
        @Query("sid") sid: String,
        @Query("amount") amount: String,
        @Query("sPK") PK: String,
        @Query("hbarFee") hbarFee: String,
        @Query("token_id") token_id: String,
        @Query("token_private_key") token_private_key: String,
        @Query("token_public_key") token_public_key: String

    ): Response

    @POST("lendingAPI/wirthdraw-amount")
    suspend fun withdraw(
        @Query("sid") rid: String,
        @Query("amount") amount: String,
        @Query("sPK") PK: String,
        @Query("hbarFee") hbarFee: String,
        @Query("token_id") token_id: String,
        @Query("token_private_key") token_private_key: String,
        @Query("token_public_key") token_public_key: String

    ): Response

    @POST("htsTokenAPI/convertToHDai")
    suspend fun convertToHDai(
        @Query("rid") rid: String,
        @Query("amount") amount: String,
        @Query("PK") PK: String,
        @Query("hbarFee") hbarFee: String,
        @Query("token_id") token_id: String,
        @Query("token_private_key") token_private_key: String,
        @Query("token_public_key") token_public_key: String


    ): ConvertToHDai


    @POST("ethereumAPI/create-eth-account")
    suspend fun createEthAccount(


    ): Response


    @POST("eth/get-eth-account")
    suspend fun getEthAccount(
            @Query("seed") seed: String

    ): Response


    @POST("ext/bc/X ")
    suspend fun sendAva(@Body  body: SendBody ): String
}