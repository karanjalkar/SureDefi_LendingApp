
async function generateMnemonic() {
    
}
module.exports = {
    generateMnemonic : async function (){

    }

}

// module.exports = generateMnemonic