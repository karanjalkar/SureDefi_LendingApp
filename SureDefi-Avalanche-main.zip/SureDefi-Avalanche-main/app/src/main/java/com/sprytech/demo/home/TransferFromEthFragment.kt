package com.sprytech.demo.home

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import com.developer.kalert.KAlertDialog
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R

import com.sprytech.demo.databinding.FragmentInvestmentBinding
import com.sprytech.demo.databinding.FragmentTransferFromEthBinding
import com.sprytech.vaccinepassport.model.Params
import com.sprytech.vaccinepassport.model.SendBody
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class TransferFromEthFragment : BaseFragment<FragmentTransferFromEthBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_transfer_from_eth

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    val viewModel: HomeFragViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService2,RetrofitBuilder.apiService3, it) }).get(HomeFragViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel


        binding.edEthAddress.text = viewModel.getEthDaiAdd()
        binding.tvEthDaiBal.text = viewModel.getEthDai()


        binding.btnSubmit.setOnClickListener {


            val ed_dai_to_transfer = binding.edDaiToTransfer.text.toString()

                viewModel.updateDAI()
                gas()
            //convertToHDai()

            //findNavController().navigate(TransferFromEthFragmentDirections.actionTransferFromEthFragmentToTransferDaiSuccessFragment("You successfully transferred DAI from your ETH wallet to Avalanche Sure-Defi wallet (AvaDAI)"))
        }


    }



    fun gas() {



        viewModel.gas().observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->

                            Log.d("DEBUG", depDai.toString())
                            Toast.makeText(activity, "GAS price received " + depDai.gas_price, Toast.LENGTH_LONG).show()

                            depDai(depDai.gas_price)
                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress("Transfering...")
                    }
                }
            }
        })



    }

    fun depDai(gas : String) {

        viewModel.depDai(gas).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->

                            Log.d("DEBUG", depDai.toString())
                            convertToHDai()
                            val dai = viewModel.no_of_dai.get().toString().toDouble()
                            // val dai = no_of_dai.get().toString().toInt()

                            val currentDai = viewModel.getEthDai()?.toDouble()

                            val updatedDai = currentDai?.minus(dai)

                          //  binding.tvAvailableDai.text = "Available DAI: " + updatedDai

                            viewModel.saveEthDai(updatedDai.toString())



                            //findNavController().navigate(TransferFromEthFragmentDirections.actionTransferFromEthFragmentToTransferDaiSuccessFragment("You successfully transferred DAI from your ETH wallet to Avalanche Sure-Defi wallet (AvaDAI)"))

                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })



    }


    fun convertToHDai() {

        //Log.d("DEBUG", "its here")

       // val profile = navGraphScopedViewModel.getCurrentUser()
       // Log.d("DEBUG", profile?.hederaAccount!!.accountId)

        val profile2 = viewModel.getCurrentUser2()

        val tokenId =profile2?.xChainAddress
        val tprk  = "302e020100300506032b657004220420432e26a8c9417838e3f8ec28b0d2ef75b461c8294bb91b74a3ac4d70f629dbc7"
        val tpvk = "302e020100300506032b657004220420432e26a8c9417838e3f8ec28b0d2ef75b461c8294bb91b74a3ac4d70f629dbc7"


        val arrayList = ArrayList<String>()//Creating an empty arraylist
        arrayList.add("X-fuji10ewuwu604lm7ypkwlf8qrp7cvwxu6ttz8khqun")
        val param = tokenId?.let {
            Params("dwvZ6vyV2cJtxz42gnGzEeKrsymzzP3KkG3DBsYYcuoe5wFyh",
                    10,
                    arrayList,
                    it,
                    "X-fuji10ewuwu604lm7ypkwlf8qrp7cvwxu6ttz8khqun",
                    "withdraw",
                    "sprytech",
                    "asd321/.,,"
        )
        }

        val sendBody = param?.let { SendBody("2.0", 1, "avm.send", it) }

        sendBody?.let {
            viewModel.convertToHDai(it).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {

                        Log.d("debug","its here too")
                        hideProgress()
                        val value = binding.edDaiToTransfer.text.toString()
                        // val address = navGraphScopedViewModel.getCurrentUser()?.hederaAccount!!.accountId
                        resource.data?.let { depDai ->



                            /*KAlertDialog(activity)
                                .setTitleText("Transfer Success!")
                                .setContentText(value + " DAI converted to hDAI and you can trade on Hedera Network")
                                .show()*/

                            findNavController().navigate(TransferFromEthFragmentDirections.actionTransferFromEthFragmentToTransferDaiSuccessFragment("You successfully transferred DAI from your ETH wallet to Avalanche Sure-Defi wallet (AvaDAI)"))

                            Log.d("DEBUG", depDai)


                        }
                    }
                    Status.ERROR -> {
                        // Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()


                        val dai = viewModel.no_of_dai.get().toString().toDouble()
                        // val dai = no_of_dai.get().toString().toInt()

                        if(!viewModel.getAvaDai().toString().equals("null")){
                            val currentDai = viewModel.getAvaDai()?.toDouble()

                            val updatedDai = currentDai?.plus(dai)

                            //  binding.tvAvailableDai.text = "Available DAI: " + updatedDai

                            viewModel.saveAvaDai(updatedDai.toString())
                        }else{
                            // val updatedDai = currentDai?.plus(dai)

                            //  binding.tvAvailableDai.text = "Available DAI: " + updatedDai

                            viewModel.saveAvaDai(dai.toString())
                        }






                        findNavController().navigate(TransferFromEthFragmentDirections.actionTransferFromEthFragmentToTransferDaiSuccessFragment("You successfully transferred DAI from your ETH wallet to Avalanche Sure-Defi wallet (AvaDAI)"))
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })
        }



    }

    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            InvestMentFragment()
    }
}