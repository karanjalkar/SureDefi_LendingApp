package com.sprytech.vaccinepassport.ui.auth.login

import android.util.Log
import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.example.play2win.LocalAuthRepository
import com.mindorks.retrofit.coroutines.utils.Resource
import com.sprytech.vaccinepassport.model.TimeD
import com.sprytech.vaccinepassport.model.UserProfile
import com.sprytech.vaccinepassport.repository.remote.IremoteRepository
import kotlinx.coroutines.Dispatchers

class WithdrawViewModel(private  val remoteRepository: IremoteRepository, private  val remoteRepository2: IremoteRepository, private val localAuthRepository: LocalAuthRepository) : ViewModel() {

    var no_of_dai = ObservableField("")
    var password = ObservableField("")

    val errorEmail = ObservableField<String>()
    val errorPassword = ObservableField<String>()


    fun gas() = liveData(Dispatchers.IO) {

        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository2.getGas()))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }

    fun depDai(gas:String) = liveData(Dispatchers.IO) {
        if(!isFormValid()) return@liveData
        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository2.getDepDai(gas)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }




    fun convertToHDai(rid:String, amount : String, pk : String, hbarfee : String, tokenId: String, tprk : String, tpvk :String ) = liveData(Dispatchers.IO) {
        if(!isFormValid()) return@liveData
        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository.convertToHDai(rid,amount,pk, hbarfee, tokenId,tprk, tpvk)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }

    fun withdraw(rid:String, amount : String, pk : String, hbarfee : String, tokenId: String, tprk : String, tpvk :String ) = liveData(Dispatchers.IO) {
       // if(!isFormValid()) return@liveData
        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository.withdraw(rid,no_of_dai.get().toString(),pk, hbarfee, tokenId,tprk, tpvk)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }

    fun depositedBalance(accountId : String) = liveData(Dispatchers.IO) {

        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository.depositedBalance(accountId)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }


    fun saveProfile(userProfile : UserProfile){
        localAuthRepository.setCurrentUser(userProfile)
    }

    fun setBalance(balance : String){
        no_of_dai.set(balance)
    }
    fun saveDepositAmount(){

        localAuthRepository.setDepositAmount(0)
    }

    fun getDepositedAmount() : Int {

        return localAuthRepository.getDepositAmount()!!
    }


    fun getTime(): TimeD {

        return localAuthRepository.getTime()!!
    }

    fun isFormValid(): Boolean {

        //Log.d("DEBUG", "its here")
        if(no_of_dai.get().toString().isEmpty()){
            errorEmail.set("Cannot be empty!")
            return false
        }else {
            errorEmail.set(null);
        }

        return true
    }

}