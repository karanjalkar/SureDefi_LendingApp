package com.sprytech.vaccinepassport.model

data class TimeD(

        val time : Long
)