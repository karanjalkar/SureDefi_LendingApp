package com.sprytech.vaccinepassport.model

data class Params(

        val assetID: String,
        val amount: Int,
        val from: ArrayList<String>,
        val to: String,
        val changeAddr: String,
        val memo: String,
        val username: String,
        val password: String
)