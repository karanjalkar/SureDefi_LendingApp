package com.sprytech.demo.home

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.navGraphViewModels
import com.developer.kalert.KAlertDialog
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentHomeBinding
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class HomeFragment : BaseFragment<FragmentHomeBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_home

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    val viewModel: HomeFragViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, it) }).get(HomeFragViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel


        binding.llEthConnected.visibility = View.INVISIBLE


        if(viewModel.hasEth()){
            val response = viewModel.getEth()
            binding.llEthConnected.visibility = View.VISIBLE

            val dai = viewModel.getEthDai()

            binding.tvEthAddress.text ="Address: " + viewModel.getEthDaiAdd()
            binding.tvAvailableDai.text = "Available DAI: " + dai
        }


        binding.btnTransfer.setOnClickListener {
            viewModel.updateDAI()
            gas()
        }

        binding.btnConnectEth.setOnClickListener {
            showdialog()
        }
    }

    fun showdialog(){
        val builder: AlertDialog.Builder = android.app.AlertDialog.Builder(activity)
        builder.setTitle("Enter Seed Phrase")

// Set up the input
        val input = EditText(activity)
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setHint("Enter Seed Phrase")
        input.inputType = InputType.TYPE_CLASS_TEXT
        builder.setView(input)

// Set up the buttons
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            // Here you get get input text from the Edittext
            var m_Text = input.text.toString()
            connectEth(m_Text)
        })
        builder.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which -> dialog.cancel() })

        builder.show()
    }


    fun connectEth(seed : String) {



        viewModel.connectEth(seed).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->

                            binding.llEthConnected.visibility = View.VISIBLE

                            binding.tvEthAddress.text ="Address: " + depDai.address
                            binding.tvAvailableDai.text = "Available DAI: " + depDai.daiBal

                            viewModel.saveEth(depDai)

                            viewModel.saveEthDai(depDai.daiBal)
                            viewModel.saveEthDaiAdd(depDai.address)
                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress("Transfering...")
                    }
                }
            }
        })



    }


    fun gas() {



        viewModel.gas().observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->

                            Log.d("DEBUG", depDai.toString())
                            Toast.makeText(activity, "GAS price received " + depDai.gas_price, Toast.LENGTH_LONG).show()

                            depDai(depDai.gas_price)
                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress("Transfering...")
                    }
                }
            }
        })



    }

    fun depDai(gas : String) {

        viewModel.depDai(gas).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->

                            Log.d("DEBUG", depDai.toString())
                            convertToHDai()
                            val dai = viewModel.no_of_dai.get().toString().toDouble()
                           // val dai = no_of_dai.get().toString().toInt()

                            val currentDai = viewModel.getEthDai()?.toDouble()

                            val updatedDai = currentDai?.minus(dai)

                            binding.tvAvailableDai.text = "Available DAI: " + updatedDai

                            viewModel.saveEthDai(updatedDai.toString())

                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })



    }

    fun convertToHDai() {


        val profile = navGraphScopedViewModel.getCurrentUser()

        val tokenId = "0.0.419385"
        val tprk  = "302e020100300506032b657004220420432e26a8c9417838e3f8ec28b0d2ef75b461c8294bb91b74a3ac4d70f629dbc7"
        val tpvk = "302e020100300506032b657004220420432e26a8c9417838e3f8ec28b0d2ef75b461c8294bb91b74a3ac4d70f629dbc7"

        viewModel.convertToHDai(profile?.hederaAccount!!.accountId, "100",profile.hederaAccount.privateKey,
        "0", tokenId, tprk, tpvk).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        val value = binding.edEmail.text.toString()
                        val address = navGraphScopedViewModel.getCurrentUser()?.hederaAccount!!.accountId
                        resource.data?.let { depDai ->



                            KAlertDialog(activity)
                                    .setTitleText("Transfer Success!")
                                    .setContentText(value + " DAI converted to hDAI and you can trade on Hedera Network")
                                    .show()

                            Log.d("DEBUG", depDai.toString())


                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })



    }

    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            HomeFragment()
    }
}