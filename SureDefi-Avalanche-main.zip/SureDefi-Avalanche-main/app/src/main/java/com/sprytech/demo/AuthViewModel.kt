package com.sprytech.demo

import android.util.Log
import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.example.metamask.repository.RemoteRepository
import com.example.play2win.LocalAuthRepository
import com.mindorks.retrofit.coroutines.utils.Resource
import com.sprytech.vaccinepassport.model.UserProfile
import com.sprytech.vaccinepassport.model.UserProfile2
import com.sprytech.vaccinepassport.repository.remote.IremoteRepository
import kotlinx.coroutines.Dispatchers

class AuthViewModel(private  val remoteRepository: IremoteRepository, private val localAuthRepository: LocalAuthRepository) : ViewModel() {

    fun saveProfile(userProfile : UserProfile){
        //Log.d("DEBUG", userProfile.hederaAccount.accountId)
        localAuthRepository.setCurrentUser(userProfile)
    }

     fun getCurrentUser() : UserProfile? {
        return localAuthRepository.getCurrentUser()
    }

    fun saveProfile2(userProfile : UserProfile2){
        //Log.d("DEBUG", userProfile.hederaAccount.accountId)
        localAuthRepository.setCurrentUser2(userProfile)
    }

    fun getCurrentUser2() : UserProfile2? {
        return localAuthRepository.getCurrentUser2()
    }


    fun isLoggedIn() : Boolean {
        return localAuthRepository.hasEverLogin()
    }

}