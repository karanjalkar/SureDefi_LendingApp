package com.sprytech.demo.home

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.sprytech.demo.R
import com.sprytech.vaccinepassport.model.Currency

class CustomDropDownAdapter(val context: Context, var dataSource: List<Currency>) : BaseAdapter() {

    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val view: View
        val vh: ItemHolder
        if (convertView == null) {
            view = inflater.inflate(R.layout.custom_spinner_item, parent, false)
            vh = ItemHolder(view)
            view?.tag = vh
        } else {
            view = convertView
            vh = view.tag as ItemHolder
        }
        vh.label.text = dataSource.get(position).name

        var iconId = 0

        if(dataSource.get(position).name.equals("HBAR")){
            iconId = R.drawable.house

        }else if(dataSource.get(position).name.equals("AVAX")){
            iconId = R.drawable.avax

        }else if(dataSource.get(position).name.equals("AvaDAI")){
            iconId = R.drawable.img_avadai
        }else if(dataSource.get(position).name.equals("AvaUSDC")){
            iconId = R.drawable.img_usdc
        }else if(dataSource.get(position).name.equals("AvaUSDT")){
            iconId = R.drawable.img_usdt
        }

        vh.img.setBackgroundResource(iconId)

        return view
    }

    override fun getItem(position: Int): Any? {
        return dataSource[position];
    }

    override fun getCount(): Int {
        return dataSource.size;
    }

    override fun getItemId(position: Int): Long {
        return position.toLong();
    }

    private class ItemHolder(row: View?) {
        val label: TextView
        val img: ImageView

        init {
            label = row?.findViewById(R.id.text) as TextView
            img = row?.findViewById(R.id.img) as ImageView
        }
    }

}