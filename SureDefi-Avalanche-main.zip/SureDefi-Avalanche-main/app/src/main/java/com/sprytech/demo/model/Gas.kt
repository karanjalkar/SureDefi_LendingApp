package com.sprytech.vaccinepassport.model

data class Gas(

        val gas_price : String
)