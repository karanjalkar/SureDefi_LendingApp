const mysql = require("mysql");

var mysqlConnection  = mysql.createPool({
  connectionLimit : 10,process.env.
  host            : '',
  user            : '',
  password        : 'zsXrIwCYy0%b',
  database        : 'test'
});

mysqlConnection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
  if (error) throw error;
  console.log('The solution is : ', results[0].solution);
});
module.exports = mysqlConnection