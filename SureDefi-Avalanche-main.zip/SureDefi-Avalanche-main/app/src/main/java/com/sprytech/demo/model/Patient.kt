package com.sprytech.vaccinepassport.model

data class Patient(
        val status : Boolean,
        val patientId: String,
        val name: String,
        val address: String,
        val dob: String,
        val blood_group: String,
        val vaccine_name: String,
        val vaccine_type: String,
        val company: String,
        val date_of_vaccine: String,
        val dose_no: String,
        val id: String,
        val patientVaccineToken: PatientVaccineToken
)