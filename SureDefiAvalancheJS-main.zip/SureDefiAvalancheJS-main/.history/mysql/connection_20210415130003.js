const mysql = require("mysql");
require('dotenv').config();

const DB_NAME = process.env.DB_NAME;

console.log({DB_NAME})
var mysqlConnection  = mysql.createPool({
  connectionLimit : 10,
  host            : process.env.DB_HOST,
  user            : process.env.DB_NAME,
  password        : process.env.DB_NAME,
  database        : process.env.DB_NAME
});

mysqlConnection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
  if (error) throw error;
  console.log('The solution is : ', results[0].solution);
});
module.exports = mysqlConnection