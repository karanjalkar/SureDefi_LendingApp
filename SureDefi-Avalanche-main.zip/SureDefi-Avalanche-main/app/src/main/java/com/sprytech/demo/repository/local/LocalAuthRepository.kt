package com.example.play2win

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import com.example.play2win.utils.mutableLiveDataWithValue
import com.sprytech.vaccinepassport.model.*

class LocalAuthRepository constructor(context: Context)
    : LocalBaseRepository(context.getSharedPreferences("authInfo", Context.MODE_PRIVATE)), ILocalAuthRepository {

    private val mutableAuthState = mutableLiveDataWithValue(false)

    override fun hasEverLogin(): Boolean =
        getData("hasEverLogin", Boolean::class) ?: false

    override fun hasTime(): Boolean =
            getData("hasTime", Boolean::class) ?: false


    fun hasEth(): Boolean =
            getData("hasEth", Boolean::class) ?: false

    override fun getCurrentUser(): UserProfile? =
        getData("userProfile", UserProfile::class)

    override fun setCurrentUser(userProfile: UserProfile) {
        putData("userProfile", userProfile)
        putData("hasEverLogin", true)
        mutableAuthState.postValue(true)
    }

     fun getCurrentUser2(): UserProfile2? =
            getData("userProfile2", UserProfile2::class)

     fun setCurrentUser2(userProfile2: UserProfile2) {
        putData("userProfile2", userProfile2)
        putData("hasEverLogin", true)
        mutableAuthState.postValue(true)
    }




    override fun clearCurrentUser() {
        putData("userProfile", null)
        putData("hasEverLogin", false)
        mutableAuthState.postValue(false)
    }


     fun getEthAccount(): Response? =
            getData("ethAccount", Response::class)

     fun setEthAccount(response: Response) {
        putData("ethAccount", response)
         putData("hasEth", true)

    }


    fun getEthDai(): String? =
            getData("ethDAI", String::class)

    fun setEthDai(response: String) {
        putData("ethDAI", response)
        putData("hasEth", true)

    }


    fun getAvaDai(): String? =
        getData("avaDai", String::class)

    fun setAvaDai(response: String) {
        putData("avaDai", response)
        putData("hasAvaDai", true)

    }

    fun getEthAddress(): String? =
            getData("ethDAIAddress", String::class)

    fun setEthAddress(response: String) {
        putData("ethDAIAddress", response)


    }

    override fun clearTime() {
        putData("hasTime", false)
    }

    override fun observeAuthState(): LiveData<Boolean> =
        mutableAuthState


    override fun setPatient(patient: Patient) {
       // Log.d("DEBUG_DB", "in here")
       // Log.d("DEBUG_DB", patient.vaccine_name)
        var patients: ArrayList<Patient> = getPatiens()

        patients.add(patient)
        //Log.d("DEBUG_DB", patients.toString())

        putData("patients", SavedPatients(patients))

    }

    override fun getPatiens(): ArrayList<Patient> {
        //Log.d("DEBUG_DB", "in here 2")
        val savedPatients = getData("patients", SavedPatients::class)
        if(savedPatients == null){
            val temps:ArrayList<Patient> = ArrayList()
            return temps
        }else{
            val patients : ArrayList<Patient> = getData("patients", SavedPatients::class)?.patients!!
            //Log.d("DEBUG_DB", getData("patients", SavedPatients::class).toString())
            val temps:ArrayList<Patient> = ArrayList()
            return patients ?: temps
        }

        //return getData("patients", SavedPatients::class)?.patients!!
    }

    override fun setTime(time: TimeD) {
        putData("time", time)
        putData("hasTime", true)
    }


    override fun getTime(): TimeD? =
            getData("time", TimeD::class)

    override fun setDepositAmount(time: Int) {
        putData("depositAmount", time)
    }

    override fun getDepositAmount(): Int? =
            getData("depositAmount", Int::class) ?: 0


}
private data class SavedPatients(
    val patients: ArrayList<Patient>
)