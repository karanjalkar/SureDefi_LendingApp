package com.sprytech.vaccinepassport.model

data class UserProfile(
        val status : Boolean,
        val id : Int,
        val name : String,
        val email : String,
        val mobile : String,
        val mnemonicePhrase : String,
        val xChainAddress : String,
        val hederaAccount: HederaAccount
)