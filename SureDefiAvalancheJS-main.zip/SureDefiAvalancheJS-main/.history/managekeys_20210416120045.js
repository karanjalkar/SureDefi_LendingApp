import {


} from ""

const { Avalanche, BinTools,
  Buffer,
  BN } = require("avalanche")

let bintools = BinTools.getInstance();

let myNetworkID = 5; //default is 3, we want to override that for our local network
let myBlockchainID = "2JVSBoinj9C2J33VntvzYtVJNZdN2NKiwwKjcumHUWEb5DbBrm"; // The X-Chain blockchainID on this network
let ava = new avalanche.Avalanche("54.154.163.205", 9650, "http", myNetworkID, myBlockchainID);
let xchain = ava.XChain(); //returns a reference to the X-Chain used by AvalancheJS

