package com.mindorks.retrofit.coroutines.data.api

import android.icu.util.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


object RetrofitBuilder {

   // private const val BASE_URL = "http://34.255.215.48:5080/"
   // private const val BASE_URL = "http://192.168.1.250:5001/"
    private const val BASE_URL = "http://34.255.215.48:5085/"
    private const val BASE_URL_2 = "http://34.255.215.48:5185/"
   // private const val BASE_URL_3= "http://34.255.215.48:5185/"
    private const val BASE_URL_3 = "http://54.154.163.205:9650/"
    private const val BASE_URL_4 = "http://34.255.215.48:5150/"
    //private const val BASE_URL_2 = "http://192.168.1.85:5185/"
   // http://34.255.215.48:5085/hederaSQLAPI/createAccount
    //http://34.255.215.48:5185/eth/depDai

    val interceptor : HttpLoggingInterceptor = HttpLoggingInterceptor().apply {
        this.level = HttpLoggingInterceptor.Level.BODY
    }

    var okHttpClient = OkHttpClient.Builder()
        .connectTimeout(1, java.util.concurrent.TimeUnit.MINUTES)
        .addInterceptor(interceptor)
        .readTimeout(300, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(150, java.util.concurrent.TimeUnit.SECONDS)
        .build()



    private fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private fun getRetrofit2(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL_2)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }


    private fun getRetrofit3(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL_3)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private fun getRetrofit4(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL_4)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val apiService: ApiService = getRetrofit().create(ApiService::class.java)
    val apiService2: ApiService = getRetrofit2().create(ApiService::class.java)
    val apiService3: ApiService = getRetrofit3().create(ApiService::class.java)
    val apiService4: ApiService = getRetrofit4().create(ApiService::class.java)
}