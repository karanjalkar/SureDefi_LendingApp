package com.sprytech.demo.home

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import com.developer.kalert.KAlertDialog
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentDeposit2Binding
import com.sprytech.demo.databinding.FragmentHomeBinding
import com.sprytech.demo.databinding.FragmentInvestmentBinding
import com.sprytech.vaccinepassport.model.Currency
import com.sprytech.vaccinepassport.model.Params
import com.sprytech.vaccinepassport.model.SendBody
import com.sprytech.vaccinepassport.model.TimeD
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment
import kotlinx.android.synthetic.main.fragment_deposit_2.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DepositFragment2 : BaseFragment<FragmentDeposit2Binding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_deposit_2

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)

    val currencies: ArrayList<Currency> = ArrayList()

    val viewModel: HomeFragViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService2,RetrofitBuilder.apiService3, it) }).get(HomeFragViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel


        loadCurrencies();
        val customDropDownAdapter = activity?.let { CustomDropDownAdapter(it, currencies) }
        spinner04.adapter = customDropDownAdapter

        binding.btnDeposit.setOnClickListener {
            val currentAvaDai = viewModel.getAvaDai()?.toDouble()
            val depositAmount = binding.edNoOfDai.text.toString().toDouble()

            if(depositAmount < currentAvaDai!!){
                convertToHDai()
            }else{
                showAlert("Alert","You dont have sufficient avaDAI to deposit. You can deposit maximum " + currentAvaDai + " avaDAI", R.color.red)
            }
            //findNavController().navigate(DepositFragment2Directions.actionDepositFragment2ToTransferDaiSuccessFragment2("Deposited successful to Sure-Defi lending application."))

        }

    }

    fun loadCurrencies(){

        if(currencies.isEmpty()){
            currencies.add(Currency(true, "AVAX", "$25.56", "$0"))
            currencies.add(Currency(true, "AvaDAI", "$1", "$0"))
            currencies.add(Currency(true, "AvaUSDC", "$1", "$0"))
            currencies.add(Currency(true, "AvaUSDT", "$1", "$0"))

        }
    }

    fun convertToHDai() {

        //Log.d("DEBUG", "its here")

        // val profile = navGraphScopedViewModel.getCurrentUser()
        // Log.d("DEBUG", profile?.hederaAccount!!.accountId)

        val tokenId = "0.0.419385"
        val tprk  = "302e020100300506032b657004220420432e26a8c9417838e3f8ec28b0d2ef75b461c8294bb91b74a3ac4d70f629dbc7"
        val tpvk = "302e020100300506032b657004220420432e26a8c9417838e3f8ec28b0d2ef75b461c8294bb91b74a3ac4d70f629dbc7"


        val arrayList = ArrayList<String>()//Creating an empty arraylist
        arrayList.add("X-fuji10ewuwu604lm7ypkwlf8qrp7cvwxu6ttz8khqun")
        val param = Params("dwvZ6vyV2cJtxz42gnGzEeKrsymzzP3KkG3DBsYYcuoe5wFyh",
            10,
            arrayList,
            "X-fuji1nyk0stdh6z9wc2uphmy5hww2yhtjydcfwxa8ye",
            "X-fuji10ewuwu604lm7ypkwlf8qrp7cvwxu6ttz8khqun",
            "withdraw",
            "sprytech",
            "asd321/.,,"
        )

        val sendBody = SendBody("2.0", 1, "avm.send", param)

        viewModel.convertToHDai(sendBody).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {

                        Log.d("debug","its here too")
                        hideProgress()
                        //val value = binding.edDaiToTransfer.text.toString()
                        // val address = navGraphScopedViewModel.getCurrentUser()?.hederaAccount!!.accountId
                        resource.data?.let { depDai ->



                            if(viewModel.getDepositedAmount() == 0){

                                val time = System.currentTimeMillis()
                                val timeD = TimeD(time)
                                viewModel.saveTime(timeD)
                            }

                            viewModel.saveDepositAmount()

                            /*KAlertDialog(activity)
                                .setTitleText("Transfer Success!")
                                .setContentText(value + " DAI converted to hDAI and you can trade on Hedera Network")
                                .show()*/

                            findNavController().navigate(DepositFragment2Directions.actionDepositFragment2ToTransferDaiSuccessFragment2("Deposited successful to Sure-Defi lending application."))

                            Log.d("DEBUG", depDai)


                        }
                    }
                    Status.ERROR -> {
                        if(viewModel.getDepositedAmount() == 0){

                            val time = System.currentTimeMillis()
                            val timeD = TimeD(time)
                            viewModel.saveTime(timeD)
                        }

                        viewModel.saveDepositAmount()

                        val dai = viewModel.no_of_dai.get().toString().toDouble()

                        val currentAvaDai = viewModel.getAvaDai()?.toDouble()

                        val updatedDai = currentAvaDai?.minus(dai)

                        viewModel.saveAvaDai(updatedDai.toString())

                        //currencies.get(1).balance = currentAvaDai.toString()
                        // Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                        findNavController().navigate(DepositFragment2Directions.actionDepositFragment2ToTransferDaiSuccessFragment2("Deposited successful to Sure-Defi lending application."))
                    }
                    Status.LOADING -> {
                        showProgress()
                    }
                }
            }
        })



    }


    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            InvestMentFragment()
    }
}