package com.sprytech.vaccinepassport.model

data class PatientVaccineToken(
        val status : Boolean,
        val tokenId : String,
        val token_private_key : String,
        val token_public_key : String,
        val fileId : String,
        val patientFileId : String
)