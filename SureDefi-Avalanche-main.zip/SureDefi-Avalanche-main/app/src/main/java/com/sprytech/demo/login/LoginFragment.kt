package com.sprytech.vaccinepassport.ui.auth.login

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.AuthViewModel
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentLogin2Binding
import com.sprytech.demo.databinding.FragmentLogin3Binding
import com.sprytech.demo.home.HomeActivity
import com.sprytech.demo.home.HomeActivity2
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [LoginFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class LoginFragment : BaseFragment<FragmentLogin3Binding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_login_3

    private val navGraphScopedViewModel: AuthViewModel by navGraphViewModels(R.id.auth_navigation)

    val viewModel: LoginViewModel by lazy {
        ViewModelProviders.of(this,
                activity?.let { ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, it) }).get(LoginViewModel::class.java)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel

        binding.tvSingup.setOnClickListener {
            findNavController().navigate(R.id.registrationFragment)
        }

        binding.btnLogin.setOnClickListener {
            //startActivity(Intent(activity, HomeActivity::class.java))
            login()

            //startActivity(Intent(activity, HomeActivity::class.java))

        }
    }



    fun login() {

        viewModel.login().observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
               // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { userProfile ->

                            if (userProfile.status) {
                                navGraphScopedViewModel.saveProfile(userProfile)
                                startActivity(Intent(activity, HomeActivity2::class.java))
                                activity?.finish()
                            } else {
                                Toast.makeText(activity, "Invalid credentials!", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                       showProgress()
                    }
                }
            }
        })



    }

    companion object {

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            LoginFragment()
    }


}