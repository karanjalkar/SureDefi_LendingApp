package com.example.play2win

import androidx.lifecycle.LiveData
import com.sprytech.vaccinepassport.model.Patient
import com.sprytech.vaccinepassport.model.TimeD
import com.sprytech.vaccinepassport.model.UserProfile

interface ILocalAuthRepository {

    fun hasEverLogin(): Boolean

    fun hasTime(): Boolean

    fun getCurrentUser(): UserProfile?

    fun setCurrentUser(userProfile: UserProfile)

    fun clearCurrentUser()

    fun clearTime()

    fun observeAuthState(): LiveData<Boolean>

    fun setPatient(patient: Patient)

    fun getPatiens() : List<Patient>

    fun setTime(time: TimeD)

    fun getTime() : TimeD?


    fun setDepositAmount(time: Int)

    fun getDepositAmount() : Int?
}