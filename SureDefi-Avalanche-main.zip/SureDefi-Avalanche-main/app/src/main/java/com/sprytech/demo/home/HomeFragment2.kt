package com.sprytech.demo.home

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.developer.kalert.KAlertDialog
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentHome2Binding
import com.sprytech.demo.databinding.FragmentHomeBinding
import com.sprytech.vaccinepassport.model.Currency
import com.sprytech.vaccinepassport.model.Patient
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class HomeFragment2 : BaseFragment<FragmentHome2Binding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_home_2

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    val currencies: ArrayList<Currency> = ArrayList()

    lateinit var adapter : CurrencyAdapter

    var deposit = 100

    var interest : Long = 0
    var currentAvaDai : Double = 0.0

    val viewModel: HomeFragViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, it) }).get(HomeFragViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel

        getPatientsHistory()

        initRecylerView()


        binding.btnTransferDaiEth.setOnClickListener {
            startActivity(Intent(activity, CreateEthWalletActivity::class.java))
        }

        binding.btnDeposit.setOnClickListener {
            if(!viewModel.getAvaDai().toString().equals("null")){

               val avaDai = viewModel.getAvaDai()?.toDouble()!!

                if(avaDai >0){
                    startActivity(Intent(activity, DepositActivity::class.java))
                }else{
                    showAlert("Alert","You dont have sufficient avaDAI to deposit. Please load avaDAI first to your avalanche account", R.color.red)
                }



            }else{
                showAlert("Alert","You dont have sufficient avaDAI to deposit. Please load avaDAI first to your avalanche account", R.color.red)
            }

        }

        binding.btnWithdraw.setOnClickListener {
            val deposit = viewModel.getDepositedAmount()
            if(deposit > 0){
                startActivity(Intent(activity, WithdrawActivity::class.java))
            }else{
                showAlert("Alert","You haven't deposited yet. Please deposit first in order to withdraw.", R.color.red)
            }

        }




    }

    override fun onResume() {
        super.onResume()

        deposit = viewModel.getDepositedAmount()

        viewModel.setDepositedBalance(deposit.toString() + "$")

        if(deposit != 0){
            timer.cancel()
            timer.start()
        }else{
            timer.cancel()
            viewModel.setWithdrawalAmount("0")
        }

        if(!viewModel.getAvaDai().toString().equals("null")){
            currentAvaDai = viewModel.getAvaDai()?.toDouble()!!

            currencies.get(1).balance = currentAvaDai.toString()

            adapter.notifyDataSetChanged()
        }


    }

    val timer = object: CountDownTimer(200000, 5000) {
        override fun onTick(millisUntilFinished: Long) {

            val startTime = viewModel.getTime()

            val currentTime = System.currentTimeMillis()

            val diff: Long = currentTime - startTime.time
            val seconds = diff / 1000
            val interest_unit = seconds / 5
            val interest = 0.32 * interest_unit
            val interestRounded = String.format("%.2f", interest).toDouble()


            val value = currentAvaDai + interestRounded
            val valueRounded = String.format("%.2f", value).toDouble()
            viewModel.setWithdrawalAmount(valueRounded.toString())


        }

        override fun onFinish() {


        }
    }


    fun initRecylerView(){
        adapter = activity?.let { CurrencyAdapter(currencies, it) }!!
        binding.recyclerView.adapter = adapter
        binding.recyclerView.layoutManager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)

        adapter?.onItemClick = {vaccine ->
            //navGraphScopedViewModel.currentPatient = vaccine
           // findNavController().navigate(R.id.vaccineDetailsFragment)
        }
    }

    fun getPatientsHistory() {
        if(currencies.isEmpty()){
            currencies.add(Currency(true, "AVAX", "$25.56", "$0"))
            currencies.add(Currency(true, "AvaDAI", "$1", "$0"))
            currencies.add(Currency(true, "AvaUSDC", "$1", "$0"))
            currencies.add(Currency(true, "AvaUSDT", "$1", "$0"))

        }
    }

    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            HomeFragment2()
    }
}