package com.sprytech.demo.home

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import androidx.fragment.app.Fragment
import android.view.View
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.navGraphViewModels
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentInvestmentBinding
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class InvestMentFragment : BaseFragment<FragmentInvestmentBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_investment

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    var deposit = 100

    var interest_unit : Long = 0
     var currentAvaDai : Double = 0.0

    val viewModel: HomeFragViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService2,RetrofitBuilder.apiService3, it) }).get(HomeFragViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel



        val deposit = viewModel.getDepositedAmount()

        binding.tvInvestment.text = "$" + deposit.toString()

        viewModel.setDepositedBalance(deposit.toString() + "$")

        if(deposit != 0){
            timer.cancel()
            timer.start()
        }else{
            timer.cancel()
            viewModel.setWithdrawalAmount("0")
        }

        if(!viewModel.getAvaDai().toString().equals("null")){
             currentAvaDai = viewModel.getAvaDai()?.toDouble()!!

            binding.tvUnit.text = currentAvaDai.toString()
            binding.tvValue.text = "$" + currentAvaDai.toString()
        }else{

            val currentAvaDai = 0.0

            binding.tvUnit.text = currentAvaDai.toString()
            binding.tvValue.text = "$" + currentAvaDai.toString()

        }



        binding.btnDeposit.setOnClickListener {
            if(!viewModel.getAvaDai().toString().equals("null")){

                val avaDai = viewModel.getAvaDai()?.toDouble()!!

                if(avaDai >0){
                    startActivity(Intent(activity, DepositActivity::class.java))
                }else{
                    showAlert("Alert","You dont have sufficient avaDAI to deposit. Please load avaDAI first to your avalanche account", R.color.red)
                }



            }else{
                showAlert("Alert","You dont have sufficient avaDAI to deposit. Please load avaDAI first to your avalanche account", R.color.red)
            }

        }

        binding.btnWithdraw.setOnClickListener {
            val deposit = viewModel.getDepositedAmount()
            if(deposit > 0){
                startActivity(Intent(activity, WithdrawActivity::class.java))
            }else{
                showAlert("Alert","You haven't deposited yet. Please deposit first in order to withdraw.", R.color.red)
            }

        }



    }



    val timer = object: CountDownTimer(200000, 5000) {
        override fun onTick(millisUntilFinished: Long) {

            val startTime = viewModel.getTime()

            val currentTime = System.currentTimeMillis()

            val diff: Long = currentTime - startTime.time
            val seconds = diff / 1000
            interest_unit = seconds / 5
            val interest = 0.32 * interest_unit
            val interestRounded = String.format("%.2f", interest).toDouble()

            val profit = currentAvaDai + interest
            val profitRounded = String.format("%.2f", profit).toDouble()
           // viewModel.setWithdrawalAmount(value.toString())

            binding.tvProfit.text = "$" + profitRounded
            binding.tvInterestUnit.text =  interest_unit.toString()
            binding.tvInterest.text = "$" + interestRounded


        }

        override fun onFinish() {


        }
    }

    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            InvestMentFragment()
    }
}