package com.sprytech.vaccinepassport.repository.remote

import com.sprytech.vaccinepassport.model.*

interface IremoteRepository {

    suspend fun login(email : String, password : String) : UserProfile
    suspend fun signUp(name : String, email : String, mobile : String, password : String) : UserProfile
    suspend fun signUpAva(name : String, email : String, mobile : String, password : String) : UserProfile2
    suspend fun patientRegistration(name : String,
                                    address : String,
                                    dob : String,
                                    blood_group : String,
                                    vaccine_name : String,
                                    vaccine_type : String,
                                    company : String,
                                    data_of_vaccine : String,
                                    dose_no : String,
                                    id : String) : Patient

    suspend fun getPatientDetails(tokenId : String) : Patient
    suspend fun getDepDai(tokenId : String) : DepDai
    suspend fun getGas() : Gas
    suspend fun getBalance(address : String) : Balance
    suspend fun depositedBalance(address : String) : Response
    suspend fun deposit(rid: String, amount : String, pk : String, hbarFee: String, token_id : String, token_private_key : String, token_public_key : String) : Response
    suspend fun withdraw(rid: String, amount : String, pk : String, hbarFee: String, token_id : String, token_private_key : String, token_public_key : String) : Response

    suspend fun convertToHDai(rid: String, amount : String, pk : String, hbarFee: String, token_id : String, token_private_key : String, token_public_key : String) : ConvertToHDai

    suspend fun createEthAccount() : Response
    suspend fun getEthAccount(seed : String) : Response
    suspend fun sendAva(body: SendBody) : String


}