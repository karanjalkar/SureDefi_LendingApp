package com.sprytech.vaccinepassport.model

data class Vaccine(
        val status : Boolean,
        val name : String,
        val tokenId : String,
        val datte : String
)