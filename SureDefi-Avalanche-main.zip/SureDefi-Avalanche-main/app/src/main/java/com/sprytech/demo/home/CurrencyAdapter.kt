package com.sprytech.demo.home

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sprytech.demo.R
import com.sprytech.vaccinepassport.model.Currency
import com.sprytech.vaccinepassport.model.Patient
import kotlinx.android.synthetic.main.card_layout.view.*


class CurrencyAdapter(val items : ArrayList<Currency>, val context: Context) : RecyclerView.Adapter<CurrencyAdapter.ViewHolder>() {


    var onItemClick: ((Currency) -> Unit)? = null
    // Gets the number of animals in the list
    override fun getItemCount(): Int {
        return items.size
    }

    // Inflates the item views


    // Binds each animal in the ArrayList to a view


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.card_layout, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        var iconId = 0


        if(items.get(position).name.equals("HBAR")){
            iconId = R.drawable.house

        }else if(items.get(position).name.equals("AVAX")){
            iconId = R.drawable.avax

        }else if(items.get(position).name.equals("AvaDAI")){
            iconId = R.drawable.img_avadai
        }else if(items.get(position).name.equals("AvaUSDC")){
            iconId = R.drawable.img_usdt
        }else if(items.get(position).name.equals("AvaUSDT")){
            iconId = R.drawable.img_usdc
        }
        holder?.icon?.setImageDrawable(context.getDrawable(iconId))
        holder?.tv_c_name?.text = items.get(position).name
        holder?.tv_c_value?.text = items.get(position).value
        holder?.tv_balance?.text = items.get(position).balance

    }

    inner class ViewHolder (view: View) : RecyclerView.ViewHolder(view) {
        // Holds the TextView that will add each animal to
        val icon = view.img_icon
        val tv_c_name = view.tv_c_name

        val tv_c_value = view.tv_c_value
        val tv_balance = view.tv_balance


        init {
            view.setOnClickListener {
                onItemClick?.invoke(items[adapterPosition])
            }
        }

    }
}

