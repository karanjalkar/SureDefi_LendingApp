package com.sprytech.vaccinepassport.ui.base

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.annotation.CallSuper
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import com.labters.lottiealertdialoglibrary.DialogTypes
import com.labters.lottiealertdialoglibrary.LottieAlertDialog
import com.sprytech.demo.R
import com.tapadoo.alerter.Alerter

abstract class BaseFragment<Binding : ViewDataBinding> : Fragment() {

    lateinit var binding: Binding

    abstract val layoutId: Int

    lateinit var alertDialog : LottieAlertDialog

    @CallSuper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, layoutId, container, false)
        binding.lifecycleOwner = viewLifecycleOwner
        return binding.root
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)

        binding.executePendingBindings()
    }



    fun hideProgress() {
        alertDialog.dismiss()
    }

    fun showProgress() {

        if(!this::alertDialog.isInitialized){
            alertDialog= LottieAlertDialog.Builder(activity, DialogTypes.TYPE_LOADING)
                .setTitle("Loading")
                .setDescription("Please Wait")
                .build()
            alertDialog.setCancelable(false)

        }

        alertDialog.show()
    }

    fun showProgress(title : String) {

        if(!this::alertDialog.isInitialized){
            alertDialog= LottieAlertDialog.Builder(activity, DialogTypes.TYPE_LOADING)
                .setTitle(title)
                .setDescription("Please Wait")
                .build()
            alertDialog.setCancelable(false)

        }

        alertDialog.show()
    }

    fun showAlert(title : String, des : String, color : Int){
        Alerter.create(activity)
            .setTitle(title)
            .setText(des)
            .setIcon(R.drawable.ic_alert_white)
            .setIconColorFilter(0)
            .setBackgroundColorRes(color) // or setBackgroundColorInt(Color.CYAN)
            .show()
    }

    open fun onBackPressed(): Boolean = false

    override fun onDestroyView() {
        binding.unbind()

        super.onDestroyView()
    }

    fun hideKeyboard(){
        val imm = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(requireView().getWindowToken(), 0)
    }


}