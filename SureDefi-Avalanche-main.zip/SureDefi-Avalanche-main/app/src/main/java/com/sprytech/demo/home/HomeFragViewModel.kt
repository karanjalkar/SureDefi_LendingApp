package com.sprytech.vaccinepassport.ui.auth.login

import android.util.Log
import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.example.play2win.LocalAuthRepository
import com.mindorks.retrofit.coroutines.utils.Resource
import com.sprytech.vaccinepassport.model.*
import com.sprytech.vaccinepassport.repository.remote.IremoteRepository
import kotlinx.coroutines.Dispatchers

class HomeFragViewModel(private  val remoteRepository: IremoteRepository, private  val remoteRepository2: IremoteRepository, private val localAuthRepository: LocalAuthRepository) : ViewModel() {

    var no_of_dai = ObservableField("")
    var password = ObservableField("")
    var deposited_amount = ObservableField("")
    val errorEmail = ObservableField<String>()
    val errorPassword = ObservableField<String>()
    var withdrawal_amount = ObservableField("")

    fun getTime(): TimeD {

        return localAuthRepository.getTime()!!
    }

    fun setDepositedBalance(balance : String){
        deposited_amount.set(balance)
    }

    fun getCurrentUser2() : UserProfile2? {
        return localAuthRepository.getCurrentUser2()
    }

    fun connectEth(seed : String) = liveData(Dispatchers.IO) {

        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository2.getEthAccount(seed)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }

    fun gas() = liveData(Dispatchers.IO) {

        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository.getGas()))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }

    fun depDai(gas:String) = liveData(Dispatchers.IO) {
        //if(!isFormValid()) return@liveData
        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository.getDepDai(gas)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }


    fun convertToHDai(rid:String, amount : String, pk : String, hbarfee : String, tokenId: String, tprk : String, tpvk :String ) = liveData(Dispatchers.IO) {
        //if(!isFormValid()) return@liveData

        /*var response = getEth()
        response?.daiBal = (response?.daiBal!!.toInt() - no_of_dai.get().toString().toInt()).toString()
        saveEth(response)
        response = getEth()

        Log.d("DEBUG", response!!.daiBal)*/

        Log.d("DEBUG", "response!!.daiBal")
        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository.convertToHDai(rid,amount,pk, hbarfee, tokenId,tprk, tpvk)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }

    fun convertToHDai(body: SendBody ) = liveData(Dispatchers.IO) {
        //if(!isFormValid()) return@liveData

        /*var response = getEth()
        response?.daiBal = (response?.daiBal!!.toInt() - no_of_dai.get().toString().toInt()).toString()
        saveEth(response)
        response = getEth()

        Log.d("DEBUG", response!!.daiBal)*/

        Log.d("DEBUG", "response!!.daiBal")
        emit(Resource.loading(data = null))
        try {
            emit(Resource.success(data = remoteRepository2.sendAva(body)))
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
        }
    }


    fun saveTime(timeD: TimeD){

        localAuthRepository.setTime(timeD)
    }

    fun setBalance(balance : String){
        no_of_dai.set(balance)
    }

    fun getDepositedAmount() : Int {

        return localAuthRepository.getDepositAmount()!!
    }

    fun saveDepositAmount2(){

        localAuthRepository.setDepositAmount(0)
    }

    fun saveDepositAmount(){

        val prevDeposit = localAuthRepository.getDepositAmount()

        val totalDeposit = prevDeposit?.plus(no_of_dai.get().toString().toInt())

        totalDeposit?.toInt()?.let { localAuthRepository.setDepositAmount(it) }
    }


    fun setWithdrawalAmount(balance : String){
        withdrawal_amount.set(balance)
    }

    fun saveEth(response: Response){
        //Log.d("DEBUG_", response.toString())
        localAuthRepository.setEthAccount(response)
    }

    fun getEth() : Response? {


        return localAuthRepository.getEthAccount()
    }



    fun saveEthDai(response: String){
        //Log.d("DEBUG_", response.toString())
        localAuthRepository.setEthDai(response)
    }

    fun getEthDai() : String? {


        return localAuthRepository.getEthDai()
    }

    fun saveAvaDai(response: String){
        //Log.d("DEBUG_", response.toString())
        localAuthRepository.setAvaDai(response)
    }

    fun getAvaDai() : String? {


        return localAuthRepository.getAvaDai()
    }


    fun saveEthDaiAdd(response: String){
        //Log.d("DEBUG_", response.toString())
        localAuthRepository.setEthAddress(response)
    }

    fun getEthDaiAdd() : String? {
        return localAuthRepository.getEthAddress()
    }

    fun getDai() : String {

        return no_of_dai.get().toString()
    }

    fun updateDAI(){
        if(!no_of_dai.get().toString().isEmpty()){

            /*val dai = no_of_dai.get().toString().toDouble()

            val currentDai = getEthDai()?.toDouble()

            val updatedDai = currentDai?.minus(dai)

            saveEthDai(updatedDai.toString())*/

        }

    }
    fun hasEth() : Boolean {

        return  localAuthRepository.hasEth()
    }


    fun saveProfile(userProfile : UserProfile){
        localAuthRepository.setCurrentUser(userProfile)
    }

    fun isFormValid(): Boolean {

        //Log.d("DEBUG", "its here")
        if(no_of_dai.get().toString().isEmpty()){
            errorEmail.set("Cannot be empty!")
            return false
        }else {
            errorEmail.set(null);
        }

        return true
    }

}