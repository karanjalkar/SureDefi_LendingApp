package com.sprytech.demo.DepositedBalance

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.navGraphViewModels
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentDepositedBalanceBinding
import com.sprytech.demo.home.HomeViewModel
import com.sprytech.vaccinepassport.ui.auth.login.DepositBalanceViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DepositBalanceFragment : BaseFragment<FragmentDepositedBalanceBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_deposited_balance

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)

    var deposit = 100

     var interest : Long = 0

    val viewModel: DepositBalanceViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, it) }).get(DepositBalanceViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        binding.viewModel = viewModel

        viewModel.setWithdrawalAmount("calculating....")

        gas()

        showData()

        deposit = viewModel.getDepositedAmount()

        viewModel.setDepositedBalance(deposit.toString())



/*        val startTime = viewModel.getTime()

        val currentTime = System.currentTimeMillis()

        val diff: Long = currentTime - startTime.time
        val seconds = diff / 1000
         interest = seconds / 5
        Log.d("DEBUG", interest.toString())*/


       if(deposit != 0){
           timer.start()
       }else{
           viewModel.setWithdrawalAmount("0")
       }


        binding.btnRefresh.setOnClickListener {
            gas()
        }
    }


    private fun showData(){

        val profile = navGraphScopedViewModel.getCurrentUser()

        binding.tvAccountId.setText("Account ID: " + profile?.hederaAccount?.accountId)
       // binding.tvPrivateKey.setText(profile?.hederaAccount?.privateKey)


    }

    val timer = object: CountDownTimer(200000, 5000) {
        override fun onTick(millisUntilFinished: Long) {

            val startTime = viewModel.getTime()

            val currentTime = System.currentTimeMillis()

            val diff: Long = currentTime - startTime.time
            val seconds = diff / 1000
            interest = seconds / 5

                val value = deposit + interest
                viewModel.setWithdrawalAmount(value.toString())


        }

        override fun onFinish() {


        }
    }

    fun gas() {



        val address = navGraphScopedViewModel.getCurrentUser()?.hederaAccount!!.accountId

        viewModel.bal(address).observe(viewLifecycleOwner, Observer {
            it?.let { resource ->
                // Log.d("DEBUG", resource.status.toString())
                when (resource.status) {
                    Status.SUCCESS -> {
                        hideProgress()
                        resource.data?.let { depDai ->

                            viewModel.setCurrentBalance(depDai.hDAIBalance)
                            viewModel.setHbar(depDai.hbarBalance)

                            Log.d("DEBUG", depDai.toString())

                        }
                    }
                    Status.ERROR -> {
                        Toast.makeText(activity, "Invalid account credentials", Toast.LENGTH_LONG).show()
                        hideProgress()
                    }
                    Status.LOADING -> {
                        showProgress("Loading...")
                    }
                }
            }
        })



    }


    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            DepositBalanceFragment()
    }
}