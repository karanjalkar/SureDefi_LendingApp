const HDKey = require('hdkey');
const bip39 = require('bip39');
const Buffer = require('buffer/').Buffer;
// const AVM = require('avalanche/dist/apis/avm');
const Utils = require('avalanche/dist/utils')
const AVAX_ACCOUNT_PATH = `m/44'/9000'/0'`;

//
const { Avalanche, BinTools,
    BN } = require("avalanche");
const avalanche = require("avalanche");
var async = require('async');
let bintools = BinTools.getInstance();

//this method is use to convert mnemonice phrase to X chain address
module.exports = {
    generateAddresses: async function (mnemonicIn, num) {
        let hrp = Utils.getPreferredHRP(1);
        let myNetworkID = 5; //default is 3, we want to override that for our local network
        let myBlockchainID = "2JVSBoinj9C2J33VntvzYtVJNZdN2NKiwwKjcumHUWEb5DbBrm"; // The X-Chain blockchainID on this network
        let ava = new avalanche.Avalanche("54.154.163.205", 9650, "http", myNetworkID, myBlockchainID);
        let xchain = ava.XChain(); //returns a reference to the X-Chain used by AvalancheJS

        let myKeychain =  myKeychain();
        let mnemonic = mnemonicIn.trim();

        if (bip39.validateMnemonic(mnemonic) == false) {
            console.log("\n\n[ERROR] Your mnemonic is invalid. Did you generate it manually? Use a proper BIP-39 mnemonic generation tool, such as the one in this repository.");
            process.exit();
        }

        const seed = bip39.mnemonicToSeedSync(mnemonic)
        const hdkey = HDKey.fromMasterSeed(seed)

        let keys = [];
        for (let i = 0; i < num; i++) {
            let derivationPath = `${AVAX_ACCOUNT_PATH}/0/${i}`;
            let key = hdkey.derive(derivationPath)
            keys.push(key);
        }

        let addrs = keys.map((key) => {
            let privateKeyHEX = key.privateKey.toString('hex');
            let privateKeyBuffer = new Buffer(privateKeyHEX, 'hex');
            let keypair = keychain.importKey(privateKeyBuffer);
            // console.log(privateKeyHEX);
            // console.log(keypair.getPublicKey().toString('hex'));
            return keypair.getAddressString();
        });

        return addrs;
    }


 
}