package com.sprytech.vaccinepassport.model

data class DepDai(

        val receiptMain : String,
        val txResult : String
)