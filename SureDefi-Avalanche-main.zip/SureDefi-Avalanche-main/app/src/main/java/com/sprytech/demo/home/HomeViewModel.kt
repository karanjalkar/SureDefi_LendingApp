package com.sprytech.demo.home

import android.util.Log
import androidx.databinding.ObservableField
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.example.metamask.repository.RemoteRepository
import com.example.play2win.LocalAuthRepository
import com.mindorks.retrofit.coroutines.utils.Resource
import com.sprytech.vaccinepassport.model.Patient
import com.sprytech.vaccinepassport.model.UserProfile
import com.sprytech.vaccinepassport.repository.remote.IremoteRepository
import kotlinx.coroutines.Dispatchers

class HomeViewModel(private  val remoteRepository: IremoteRepository, private val localAuthRepository: LocalAuthRepository) : ViewModel() {

    private val mutableRefreshBalance: MutableLiveData<Unit> = MutableLiveData()
    val refreshBalance: LiveData<Unit> = mutableRefreshBalance

    private val mutableScannedString: MutableLiveData<String> = MutableLiveData()
    val scannedString: LiveData<String> = mutableScannedString

    lateinit var currentPatient: Patient

    fun saveProfile(userProfile : UserProfile){
        //Log.d("DEBUG", userProfile.hederaAccount.accountId)
        localAuthRepository.setCurrentUser(userProfile)
    }

     fun getCurrentUser() : UserProfile? {
        return localAuthRepository.getCurrentUser()
    }

    fun isLoggedIn() : Boolean {
        return localAuthRepository.hasEverLogin()
    }

    fun clearCurrentUser() {
        localAuthRepository.clearCurrentUser()
    }

    fun savePatient( patient: Patient){
        currentPatient = patient
        //Log.d("DEBUGinview", patient.name)
        localAuthRepository.setPatient(patient)

        //val patients = getPatients()
        //Log.d("DEBUG_FINAL", patients.get(0).name)
    }

    fun getPatients() : ArrayList<Patient>{
        return localAuthRepository.getPatiens()
    }

    fun refreshBalance() {
        mutableRefreshBalance.value = Unit
    }

    fun setScannedValue(value : String) {
        mutableScannedString.value  = value
    }

}