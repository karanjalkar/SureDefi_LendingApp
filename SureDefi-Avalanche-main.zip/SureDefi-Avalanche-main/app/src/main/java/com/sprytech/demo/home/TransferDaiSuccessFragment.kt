package com.sprytech.demo.home

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.navGraphViewModels
import com.developer.kalert.KAlertDialog
import com.mindorks.retrofit.coroutines.data.api.RetrofitBuilder
import com.mindorks.retrofit.coroutines.ui.base.ViewModelFactory
import com.mindorks.retrofit.coroutines.utils.Status
import com.sprytech.demo.R
import com.sprytech.demo.databinding.FragmentHomeBinding
import com.sprytech.demo.databinding.FragmentInvestmentBinding
import com.sprytech.demo.databinding.FragmentTransferDaiSuccessBinding
import com.sprytech.vaccinepassport.ui.auth.login.HomeFragViewModel
import com.sprytech.vaccinepassport.ui.base.BaseFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class TransferDaiSuccessFragment : BaseFragment<FragmentTransferDaiSuccessBinding>() {

    override val layoutId: Int = com.sprytech.demo.R.layout.fragment_transfer_dai_success

    private val navGraphScopedViewModel: HomeViewModel by navGraphViewModels(R.id.home_navigation)


    val viewModel: HomeFragViewModel by lazy {
        ViewModelProviders.of(this,
            activity?.let { ViewModelFactory(RetrofitBuilder.apiService,RetrofitBuilder.apiService2, it) }).get(HomeFragViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.viewModel = viewModel


        val msg: String? =
            arguments?.let { TransferDaiSuccessFragmentArgs.fromBundle(it).msg2 }

        binding.tvMsg.text = msg

        binding.btnHome.setOnClickListener {
            activity?.finish()
        }

    }


    companion object {

        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            InvestMentFragment()
    }
}